<?php
include 'koneksi.php';
$no = 1;

if(isset($_POST['bcari'])){
    $keyword= $_POST['tcari'];
    $q ="SELECT * FROM penyewa where nama like '%$keyword%' or alamat like '%$keyword%' order by id desc";
}else{
    $q ="SELECT * from penyewa order by id desc";
}

$data = mysqli_query($koneksi, $q);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sewaan</title>
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        table, th, td {
            border: 1px solid;
            border: 1px solid #ddd;
            padding: 8px;
        }
        table th, td {
            border: 1px solid;
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
        }
        table {
            width: 100%;
            text-align: center;
            background-color: #ddd;
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #2a2c39;
            color: whitesmoke;
        }
    </style>
</head>
<body>
    <table>
        <form method="POST">
            <div class="input-group mb-3">
                <input type="text" name="tcari" class="form-control" placeholder="Masukkan nama/kelas">
                <button class="btn btn-warning" name="bcari" type="submit">Cari</button>
                <button class="btn btn-danger" name="breset" type="reset" value="Reset">Reset</button>
            </div>
        </form>
        <tr>
            <th>No</th>
            <th>ID</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>No HP</th>
            <th>Hapus Data</th>
            <th>Edit Data</th>
        </tr>
        <?php while ($d = mysqli_fetch_array($data)) { ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $d['id']; ?></td>
                <td><?php echo $d['nama']; ?></td>
                <td><?php echo $d['alamat']; ?></td>
                <td><?php echo $d['no_hp']; ?></td>
                <td><a href="hapus.php?id=<?php echo $d["id"]; ?>" onclick="return confirm('Apakah kamu ingin menghapus data ini?')">HAPUS</a></td>
                <td><a href="edit.php?id=<?php echo $d["id"]; ?>" onclick="return confirm('Apakah kamu ingin mengedit data ini?')">EDIT</a></td>
            </tr>
        <?php } ?>
    </table>
</body>
<svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none">
    <defs>
        <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z">
    </defs>
    <g class="wave1">
        <use xlink:href="#wave-path" x="50" y="3" fill="rgba(255,255,255, .1)">
    </g>
    <g class="wave2">
        <use xlink:href="#wave-path" x="50" y="0" fill="rgba(255,255,255, .2)">
    </g>
    <g class="wave3">
        <use xlink:href="#wave-path" x="50" y="9" fill="#fff">
    </g>
</svg>
</html>
