<?php 
 
include 'koneksi.php';
$id = $_POST['id'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['no_hp'];
$nama_motor = $_POST['nama_motor'];
 
mysqli_query($koneksi,"update penyewa set id='$id', nama='$nama', alamat='$alamat', no_hp='$no_hp', nama_motor='$idnama_motor'  where id='$id'");
 
header("location:sewaan.php");
 
?>