<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Motor2</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="banner">
    <video autoplay loop muted>
      <source src="vidiobackground/videoplayback (2).mp4">
    </video>
  </div>
  </div>
</body>
</html> 
<!DOCTYPE html>
<html lang="en">
  <section id="hero" class="d-flex flex-column justify-content-end align-items-center">
    <div id="heroCarousel" data-bs-interval="5000" class="container carousel carousel-fade" data-bs-ride="carousel">

  <div class="carousel-item active">
    <div class="carousel-container">
    <a href="tampilanawal.php" class="btn-get-started animate__animated animate__fadeInUp scrollto">Kembali</a>
  <p class="animate__animated fanimate__adeInUp">Nama Motor :ZX25r</p>
  <p class="animate__animated fanimate__adeInUp">CC Motor   :250CC</p>
  <p class="animate__animated fanimate__adeInUp">Warna Motor:Hijau</p>
  <h2 class="animate__animated animate__fadeInDown">Harga Sewa Motor:700.000.00<span></span></h2>
       <a href="penyewa.php" class="btn-get-started animate__animated animate__fadeInUp scrollto">Sewa Motor </a>  

  <section id="hero" class="d-flex flex-column justify-content-end align-items-center">

      <head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="description">
  <meta content="" name="keywords">

 
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">



<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center  header-transparent ">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <h1><a href="index.html">Sewa Motor Yang Anda Sukai</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      
            
        
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->